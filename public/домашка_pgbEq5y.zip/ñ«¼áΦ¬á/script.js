1
// const arr = ['a', 'b', 'c'];
// let res = arr.unshift(1, 2, 3);
// let tipe = arr.push(1, 2, 3)
// console.log(arr);

2
// const arr = [1, 2, 5, 9, 4, 13, 4, 10];
// let res = arr.shift();
// let ser = arr.pop();
// console.log(arr);


3
// let array = ['js', 'css', 'jq'];
// let firstEl = array.shift();
// console.log(firstEl);
// let lastEl = array.pop();
// console.log(lastEl);

5
// let arr = [1, 2, 5, 9, 4, 13, 4, 10];

// for (let i = 0; i < arr.length; i++) {
//     if (arr[i] === 4) {
//         console.log('Есть');
//         break; 
//     }
// }

6
// const arr = [1, 2, 3, 4, 5];
// let slArr = arr.slice(0, 3);

// console.log(slArr); 


let array = [1, 2, 3, 4, 5];


array.splice(1, 2);

console.log(array);




